<html>
<body>
<form action="welcome.jsp">
Name: <input type="text" name="name">
<input type="submit">
</form>
</body>
</html>
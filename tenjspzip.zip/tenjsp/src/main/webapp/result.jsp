<%
String n1=request.getParameter("n1");
String n2=request.getParameter("n2");

if(n1!=null && n2!=null)
{
int a=Integer.parseInt(n1);
int b=Integer.parseInt(n2);
int sum=a+b;
%>

Result = <%=sum%>

<%
}
else
{
out.println("Please enter numbers first.");
}
%>
<%
String name=request.getParameter("name");
session.setAttribute("user",name);
%>
Welcome <%=session.getAttribute("user")%>
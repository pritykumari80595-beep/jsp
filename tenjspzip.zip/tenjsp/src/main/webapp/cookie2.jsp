<%
Cookie c[]=request.getCookies();
for(Cookie x:c)
{
if(x.getName().equals("username"))
{
out.println("User: "+x.getValue());
}
}
%>
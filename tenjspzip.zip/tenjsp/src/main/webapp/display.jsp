<%
String name=request.getParameter("name");
String email=request.getParameter("email");
%>
<html>
<body>
Name: <%=name%><br>
Email: <%=email%>
</body>
</html>
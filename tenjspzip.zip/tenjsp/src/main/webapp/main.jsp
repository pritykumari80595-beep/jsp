<%@ include file="header.jsp" %>

This is main content.

<%@ include file="footer.jsp" %>
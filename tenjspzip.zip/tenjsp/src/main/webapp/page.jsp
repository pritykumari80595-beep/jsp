<%
response.setHeader("Refresh","5;URL=next.jsp");
%>

Redirecting in 5 seconds...
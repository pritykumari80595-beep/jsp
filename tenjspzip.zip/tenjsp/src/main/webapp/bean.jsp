
<jsp:useBean id="s" class="model.student"/>

Student Name: ${s.name}
<%@ page import="java.util.*" %>

<%
ArrayList<String> products=new ArrayList<>();

products.add("Laptop");
products.add("Mobile");
products.add("Tablet");

request.setAttribute("p",products);
%>

<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<c:forEach var="item" items="${p}">
${item} <br>
</c:forEach>
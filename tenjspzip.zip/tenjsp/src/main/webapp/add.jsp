<html>
<body>

<form action="result.jsp" method="get">

Number 1: <input type="text" name="n1"><br><br>

Number 2: <input type="text" name="n2"><br><br>

<input type="submit" value="Add">

</form>

</body>
</html>
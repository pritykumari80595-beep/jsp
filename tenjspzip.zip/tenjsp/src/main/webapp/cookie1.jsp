<%
Cookie c=new Cookie("username","Prity");
response.addCookie(c);
%>
Cookie Created
<a href="cookie2.jsp">Next Page</a>
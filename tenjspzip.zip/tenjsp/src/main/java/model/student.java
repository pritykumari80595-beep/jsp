package model;

public class student {

    String name="Prity";

    public String getName(){
        return name;
    }
}